# generators
# generators are iterable
# as we know diff between iterators and iterable
# list=[4,5,6] takes more memory and time while genrators are iterators takes less time 