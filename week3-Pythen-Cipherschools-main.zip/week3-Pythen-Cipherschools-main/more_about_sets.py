# we can use in keyword and for loop in sets
set1={"satish","ramesh","kamlesh","raju","baburao"}
if "kallu" in set1:
    print("present")
for i in set1:
    print(i)


    # union and intersection in sets
# we use | for union 
# we use & for intersection
s1={1,2,3,4,5,6,7,8,9,0,1.21}
s2={2,3,4,5,8,11,10,5,45}
print(s1|s2)
print(s1&s2)