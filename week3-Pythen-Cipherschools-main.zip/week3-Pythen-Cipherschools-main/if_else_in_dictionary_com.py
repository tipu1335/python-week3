b={i:("even" if i%2==0 else "odd") for i in range(1,21)}
print(b)
