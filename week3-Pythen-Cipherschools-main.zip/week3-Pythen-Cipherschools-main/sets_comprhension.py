set1={chr(k**2) for k in range(1,33)}
print(set1)