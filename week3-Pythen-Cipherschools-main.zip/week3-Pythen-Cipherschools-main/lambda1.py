sum1=lambda x,y :x+y
print(sum1(52.6,78))
def add(s1,s2):
    return(s1+s2)
print(add)
print(sum1)
# sum1 is not any name of the function like add
