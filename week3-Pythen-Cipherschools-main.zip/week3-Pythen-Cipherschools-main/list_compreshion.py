list1=[i*i for i in range(1,11)]
print(list1)
# insted for writing whole loop we can use list compresion it is only avilable in pythen
# this type of code is called pytenic code