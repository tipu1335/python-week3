def rev(s):
    lis2=[i[::-1] for i in s]
    return lis2


list1=["kamlesh","satish","babu maan","kalua"]
print(rev(list1))
