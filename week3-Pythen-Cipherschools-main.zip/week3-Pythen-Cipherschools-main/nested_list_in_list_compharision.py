kamlesh=[[i for i in range(0,8)] for j in range(0,4)]
print(kamlesh)