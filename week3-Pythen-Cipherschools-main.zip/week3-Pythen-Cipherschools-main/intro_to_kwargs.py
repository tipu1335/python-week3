def func(**kwargs):
    print(kwargs)
    print(type(kwargs))
# ** will take argument as a dictionary
func(name="satish kumar",roll_no="38")
