odd_even=lambda x : "even" if x%2==0 else "false"
print(odd_even(3))
last_char=lambda y: y[-1]
print(last_char("sattu"))