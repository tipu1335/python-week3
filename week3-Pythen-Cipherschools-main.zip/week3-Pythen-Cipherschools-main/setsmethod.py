# to add
set1={"satish","ramesh","kamlesh","raju","baburao"}
set1.add("kallu")
print(set1)
# to remove
set1.remove("kallu")
print(set1)
# to descard agar element present nahi in sets then it displays None
set1.discard("satish")
print(set1)
set1.discard("kallu")
print(set1)
# we can also use copy method
# also clear method just like list
