def norma_parameters(num,*args):
    return (num,args)
print(norma_parameters(5,6,4,5,8,7,4,1,2,3,6,5,4,7,8,9))
# ok got it