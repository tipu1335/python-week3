a={i:i*i for i in range(1,11)}
print(a)
b={f"square of {j} id":j*j for j in range(1,11)}
print(b)
c="kamleshsingh"
d={k:c.count(k) for k in c}
print(d)