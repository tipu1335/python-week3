gen1=(i**2 for i in range(1,80))
# generating genrators is same like genration list just we use paranthesis instead of sq. brackets
print(gen1)
for i in gen1:
    print(i,end="")