nums1=list(range(1,52))
nums2=[i for i in nums1 if i%2==0]
# wese hi odd ki bna sakte hai
print(nums2)