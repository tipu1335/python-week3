# sets data type
# unordered collection of data
set1={1,2,3,4,5,6,7,8,9,1,2,1,2,1,2,}
print(set1)
# we cannot use index in sets
list1=[1,5,8,8,8,5,5,6,9,8,4,54,44,5,8,5,8,5,4,7,4]
print(list(set(list1)))
# best use of set

